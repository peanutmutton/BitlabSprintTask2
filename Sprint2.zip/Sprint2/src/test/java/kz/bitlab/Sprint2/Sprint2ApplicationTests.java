package kz.bitlab.Sprint2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprint2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
